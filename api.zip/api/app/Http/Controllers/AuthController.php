<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;

class AuthController extends Controller
{

    public function index(Request $request)
    {
        // Base query for users excluding those with status "Deleted"
        $query = User::where('status', '!=', 'Deleted');

        // Apply role filter if provided
        if ($request->query('role')) {
            $query->where('role', $request->query('role'));
        }

        // Get the users with ordering
        $users = $query->orderBy('created_at', 'desc')->get();

        return response()->json($users);
    }



    public function register(Request $request)
    {
        $request->validate([
            'full_name' => 'required|max:255',
            'user_name' => 'required|unique:users',
            'password' => 'required|confirmed'
        ]);

        $user = User::create($request->all());

        if ($user) {
            return ([
                'message' => 'User added'
            ]);
        }
    }

    public function update(Request $request, $id)
    {
        $user = User::find($id);
        $data = $request->all();
        $user->update($data);

        return response()->json(['message' => $id]);
    }


    function login(Request $request)
    {
        $request->validate([
            'user_name' => 'required|exists:users,user_name',
            'password' => 'required'
        ]);

        $username = strtolower($request->user_name);

        if (RateLimiter::tooManyAttempts('login:' . $username, 3)) {
            return response()->json([
                'message' => 'Too many login attempts. Please try again in a minute.'
            ], 429);
        }

        $user = User::where('user_name', $username)->where('status', 'Active')->first();

        if ($user && Hash::check($request->password, $user->password)) {
            $token = $user->createToken($username)->plainTextToken;

            $user->update(['last_login' => Carbon::now()]);

            RateLimiter::clear('login:' . $username);

            return response()->json([
                'user_name' => $user->user_name,
                'full_name' => $user->full_name,
                'role' => $user->role,
                'token' => $token,
                'permissions' => $user->permissions
            ], 200);
        } else {
            RateLimiter::hit('login:' . $username);

            return response()->json([
                'message' => 'The provided credentials are incorrect.'
            ], 401);
        }
    }

    function logout(Request $request)
    {
        $request->user()->tokens()->delete();
        return ['message' => 'Logged out'];
    }
}
