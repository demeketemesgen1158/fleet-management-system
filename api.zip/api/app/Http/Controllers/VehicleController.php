<?php

namespace App\Http\Controllers;

use Carbon\Carbon;
use App\Models\Vehicle;
use Illuminate\Http\Request;

class VehicleController extends Controller
{
    /**
     * Retrieve all vehicles or filter by date range.
     */
    public function index(Request $request)
    {
        $date_start = $request->query('date_start');
        $date_end = $request->query('date_end');

        if ($date_start !== "null" && $date_end !== "null") {
            // Adjust date_end to include the full day
            $date_end = Carbon::parse($date_end)->endOfDay();

            // Filter vehicles by date range and availability
            $vehicles = Vehicle::whereBetween('created_at', [$date_start, $date_end])
                ->where('availability', 'available')
                ->get();

            return response()->json($vehicles);
        }

        // Return all available vehicles if no date range is provided
        $vehicles = Vehicle::where('availability', 'available')->get();

        return response()->json($vehicles);
    }

    /**
     * Store a new vehicle record.
     */
    public function store(Request $request)
    {
        // Get all request data and add default 'reason'
        $vehicle_data = $request->all();

        // Create a new Vehicle record
        Vehicle::create($vehicle_data);

        // Return a success message
        return response()->json([
            'message' => 'Added successfully',
        ], 201);
    }

    /**
     * Update an existing vehicle record.
     */
    public function update(Request $request, Vehicle $vehicle)
    {
        // Update the vehicle with the provided data
        $vehicle->update($request->all());

        // Return a success message
        return response()->json(['message' => 'Updated successfully']);
    }
}
