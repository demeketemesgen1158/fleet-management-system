<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('vehicles', function (Blueprint $table) {
            $table->id();
            $table->string('vehicle_id')->unique();
            $table->string('make');
            $table->string('model');
            $table->year('year');
            $table->string('license_plate');
            $table->string('status');
            $table->string('fuel_type');
            $table->decimal('mileage', 10, 2);
            $table->date('last_service');
            $table->date('next_service');
            $table->string('availability')->default('available');
            $table->string('data_encoder');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('vehicles');
    }
};
