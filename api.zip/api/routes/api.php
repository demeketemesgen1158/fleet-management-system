<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\VehicleController;

Route::apiResource('vehicle', VehicleController::class);

// Routes that do not require authentication
Route::post('/users/register', [AuthController::class, 'register']);
Route::post('/users/login', [AuthController::class, 'login']);

// Routes that require authentication using Sanctum
Route::middleware('auth:sanctum')->group(function () {
    Route::get('/users', [AuthController::class, 'index']);
    Route::put('/users/update/{id}', [AuthController::class, 'update']);
    Route::post('/users/logout', [AuthController::class, 'logout']);
});
